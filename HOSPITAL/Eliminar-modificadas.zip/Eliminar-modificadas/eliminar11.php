﻿<?
$dbhost="localhost";  // host del MySQL (generalmente localhost)
$dbusuario="root"; // aqui debes ingresar el nombre de usuario
                      // para acceder a la base
$dbpassword="Ga19961904"; // password de acceso para el usuario de la
                      // linea anterior
$db="hospital";        // Seleccionamos la base con la cual trabajar
$tabla="laboratorio";

$conexion = @mysql_connect($dbhost, $dbusuario, $dbpassword);
if (!$conexion){
	exit('<p>No pudo realizarce la conexión a la base de datos.</p>');
}
if (!@mysql_select_db($db, $conexion)){
	exit ('<p>Problema al seleccionar la base de datos $db.</p>');
}

if (!$_GET /*($accion)*/){
	?>
    <html>
    <head><title>Datos en la Base </title></head>
    <body bgcolor=white>

	<?
	$sql = "select * from ".$tabla;
	

	$resultado = @mysql_query($sql);
	if(!$resultado){
		exit('<p>Error en el Query.'.$resultado.'</p>');
	}
?>
<font color=red face=Arial><h1><div align="center">Contenido de la Base de Datos <?php echo $db.", Tabla ".$tabla;?></div></h1>
<table align="center" border=1 cellpadding="1">
<tr><th>ID_LAB</th>
<th>LABORATORIO</th>

</tr>

<?
while ($row=mysql_fetch_array($resultado)){
echo "<tr><td>". $row["ID_LAB"]. "</td>";
echo "<td>". $row["NOM_LAB"]. "</td>";

	echo "<td><a href=".$_SERVER['PHP_SELF']."?borrar=".$row['ID_LAB'].">Borrar</a></td></tr>";
}
?>
	</form>
	</body>
	</html>
<?
}
else {
	if (isset ($borrar)){
		?>
    	<html>
    	<head><title>Eliminando datos</title></head>
    	<body bgcolor=orange>
		<?
		//echo "borrar".$borrar;
		$sql="DELETE FROM laboratorio WHERE ID_LAB=".$borrar;
		//echo "sql=".$sql;

		if(@mysql_query($sql)){

			echo "<p>Elemento eliminado.</p>";
		}
		else{
		 	echo mysql_errno();
			echo "<p>Error al eliminar el elemento.</p>";
		}
		
		
	}
}
 mysql_close($conexion); ?>

	</table>
	<div align="center"><p><a href="Bienvenida.php">Regresar al menú principal</a></p></div>
	</body>
	</html>